package com.xzz.fly;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;
import javax.swing.JPanel;

import com.sun.prism.Graphics;

//游戏操作类
public class BirdGame extends JPanel{

	public BufferedImage bg, sImage, gImage;//缓存区
	public Ground ground;//声明地面属性
	public Bird bird;//声明小鸟属性
	public Column columns[];//声明管道属性
	public int score = 0;//游戏分数
	public int state;	//游戏状态
	public static final int START = 0;//游戏开始状态
	public static final int RUNNING = 1;//游戏进行状态
	public static final int GAMEOVER = 2;//游戏结束状态

	public BirdGame() {//构造方法:创建类的时候，调用此方法
		try{
			state = START;//使游戏运行后使开始状态
			//读取项目中图片赋值给属性
			bg = ImageIO.read(getClass().getResource("bg.png"));//背景
			sImage = ImageIO.read(getClass().getResource("start.png"));//开始图片
			gImage = ImageIO.read(getClass().getResource("gameover.png"));//结束图片
			ground = new Ground();//创建地面类对象的时候，调用Ground里面的构造方法
			bird = new Bird();//创建小鸟类对象
			columns = new Column[2];//创造管道数组，赋值为2
			columns[0] = new Column();//创建两个管道
			columns[1] = new Column();
		}catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("图片未找到");
		}
	}

	//绘画方法
	@Override
	public void paint(java.awt.Graphics g) {
		// TODO Auto-generated method stub
		super.paint(g);
		//属性	X轴	Y轴	observer要通知的对象
		g.drawImage(bg, 0, 0, null);//画背景
		g.drawImage(columns[0].cimage, columns[0].x, columns[0].y,null);//画管道1
		g.drawImage(columns[1].cimage, columns[1].x, columns[1].y,null);//画管道2
		g.drawImage(ground.image, ground.x, ground.y, null);//画地面

		switch (state) {
			case START:
				g.drawImage(sImage, -25, 0, null);//画开始页面
				break;

			case GAMEOVER:
				g.drawImage(gImage, -25, 0, null);//画结束页面
				break;

			default:
				break;
		}
		g.drawImage(bird.image, bird.x, bird.y, null);//画小鸟
		setScore(g);//调用定义分数的方法画出分数
	}

	//定义分数
	public void setScore(Graphics g) {
		Font font = new Font(Font.SERIF,Font.ITALIC,50);
		g.setFont(font);
		g.setColor(Color.PINK);
		g.drawString(score+"", 40, 60);
	}

	//检测小鸟是否碰撞地面
	public boolean isHitGround() {
		if(bird.y <500 - bird.height) {
			return false;//没碰到
		}else {
			return true;//碰到了
		}
	}

	//判断小鸟是否碰撞管道
	public boolean isHitColumn(Column column) {
		//先考虑小鸟的x轴坐标与管道的x轴坐标
		//1.小鸟在管道左侧：小鸟x轴坐标 >= 管道的x轴坐标 - 小鸟图片的宽度
		//2.小鸟在管道右侧：小鸟x轴坐标 <= 管道的x轴坐标 + 管道的宽度
		if(bird.x >= column.x - bird.width && bird.x <= column.x + column.width) {
			//在范围内不考虑缺口就是碰到了
			//所以去考虑y轴坐标的关系
			//半个管道的长度：整个管道的高度/2-72
			//1.小鸟在管道上方：小鸟y轴坐标 <= 管道y + 半个管道
			//2.小鸟在管道下方：小鸟y轴坐标 >= 管道y + 管道宽度 / 2 + 72 - 小鸟高度
			if(bird.y <= (column.y + column.height / 2 -72) || bird.y >= (column.y + column.height / 2 + 72 - bird.height)) {
				return true;
			}else {
				return false;//没碰到
			}
		}else {
			return false;//没碰到
		}
	}

	//让游戏整个动起来的方法
	public void action() {
		this.addMouseListener(new BirdMouselistener());//调用内部类
		while(true) {
			switch (state) {
				case START://游戏开始
					ground.step();//地面动
					bird.fly();//小鸟原地动
					break;

				case RUNNING://游戏进行
					ground.step();//地面动
					bird.fly();//小鸟原地动
					bird.down();//小鸟上下移动
					//使用循环方法，遍历管道。调用管道移动方法
					for (int i = 0; i < columns.length; i++) {
						Column column = columns[i];
						column.staep();
						if (isHitColumn(column)) {
							state = GAMEOVER;//碰撞管道游戏结束
							break;
						}
						//判断小鸟飞过管道 分数++
						//小鸟X == 管道x + 管道宽度
						if (bird.x == column.x + column.width) {
							score++;
						}
					}

					//小鸟碰撞地面，游戏结束
					if(isHitGround()) {
						state = GAMEOVER;
					}

//				if(a()) {//1
//					state = GAMEOVER;
//				}
//				break;

				case GAMEOVER://游戏结束
					break;

				default:
					break;
			}
			repaint();//重新绘制，执行paint方法

			try {
				Thread.sleep(1000/60);//控制移动速度
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}

	//内部类：监听鼠标点击事件
	class BirdMouselistener extends MouseAdapter {
		//鼠标点击
		@Override
		public void mousePressed(MouseEvent e) {
			// TODO Auto-generated method stub
			super.mousePressed(e);
			switch (state) {
				case START://游戏开始
					state = RUNNING;//让游戏状态改为进行中
					break;

				case RUNNING://游戏进行
					bird.up();//给小鸟一个初始速度
					break;

				case GAMEOVER://游戏结束
					state = START;//让游戏状改为开始
					bird.x = 120;//初始化小鸟数据
					bird.y = 220;
					bird.speed = 0;
					Column.count = 0;//初始化管道数据
					columns[0] = new Column();
					columns[1] = new Column();
					score = 0;
					break;

				default:
					break;
			}
		}
	}
}
