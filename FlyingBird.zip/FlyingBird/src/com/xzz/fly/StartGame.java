package com.xzz.fly;

import javax.swing.JFrame;

//游戏入口类
public class StartGame {
	public static void main(String[] args) {

		//绘制游戏窗口
		JFrame frame = new JFrame("飞扬的小鸟");
		//设置窗口大小
		frame.setSize(400,670);
		//设置窗口的位置	null居中
		frame.setLocationRelativeTo(null);
		//关闭应用程序
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		//将BirdGame类添加进来
		BirdGame game = new BirdGame();
		frame.add(game);
		//可视化窗口
		frame.setVisible(true);
		//调用游戏动起来的方法
		game.action();
	}
}
