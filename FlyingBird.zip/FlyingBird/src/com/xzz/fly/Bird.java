package com.xzz.fly;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

//小鸟类
public class Bird {

	public BufferedImage image;//小鸟当前状态的图片
	public BufferedImage images[];//小鸟所有状态的图片
	public int x;//x轴坐标
	public int y;//y轴坐标
	public int width;//宽度
	public int height;//高度
	public int index = 0;//下标
	public double speed = 0;//初始速度
	public double upspeed = 20;//上抛速度
	public double t = 0.2;//上移时间
	public double g = 9.8;//重力加速度
	public double s = 0;//位移

	public Bird() {

		try {
			x = 120;
			y = 220;
			image = ImageIO.read(getClass().getResource("0.png"));
			images = new BufferedImage[8];//创建长度为8的数组存储小鸟所有状态的图片

			for (int i = 0; i < images.length; i++) {
				images[i] = ImageIO.read(getClass().getResource(i + ".png"));
			}
			width = image.getWidth();//获取图片的宽度和高度
			height = image.getHeight();

		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("图片未找到");
		}
	}
	//让小鸟实现动态效果
	public void fly() {
		index++;//在开始页面
		image = images[index/8%8];
	}

	//小鸟速度变化赋值
	public void up() {
		speed = upspeed;
	}
	//小鸟点击移动距离的变化！！！
	public void down() {
		double v = speed;
		s = v * t - g * t * t / 2;//s是小鸟沿y轴真正移动的距离
		y = (int) (y - s);//将s强转为int类型
		speed = v - g * t;//上抛速度 - g = 小鸟的速度
	}
}
