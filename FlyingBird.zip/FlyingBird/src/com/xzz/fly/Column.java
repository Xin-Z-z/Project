package com.xzz.fly;

import java.awt.image.BufferedImage;
import java.io.IOException;
import java.util.Random;

import javax.imageio.ImageIO;
//管道类
public class Column {

    public int gap = 144;//管道中间的缺口是144
    public BufferedImage cimage;//管道图片
    public int x;//x轴坐标
    public int y;//y轴坐标
    public int width;//宽度
    public int height;//高度
    public static int count = 0;//管道个数
    public int distance = 270;//管道之间的距离
    public Random rand = new Random();

    public Column() {
        try {
            cimage = ImageIO.read(getClass().getResource("column.png"));
            width = cimage.getWidth();//获取图片的宽度和高度
            height = cimage.getHeight();
            //第一个管道的x轴坐标：410 + distance * 0
            //第二个管道的x轴坐标：410 + distance * 1
            //第三个管道的x轴坐标：410 + distance * 2
            x = 410 + distance * count;
            y = rand.nextInt(300) + 100 - height / 2;
        } catch (IOException e) {
            // TODO Auto-generated catch block
            System.out.println("图片未找到");
        }
        count++;
    }

    //管道移动的方法
    public void staep() {
        x--;
        if(x == -width / 2) {
            //当最左边的管道移动到了管道宽度的x轴时，
            //我们需要重新计算下一个新管道的x轴主表
            //因为每次都有两个管道生成在页面上
            //所有新管道的x轴坐标 = 最左边的管道x轴坐标 +
            //新管道距离最左边的管道之间的距离：distance * 2
            x = x + distance * 2;
            y = rand.nextInt(300) + 100 - height / 2;
        }
    }
}
