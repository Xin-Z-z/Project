package com.xzz.fly;

import java.awt.image.BufferedImage;
import java.io.IOException;

import javax.imageio.ImageIO;

//地面类
public class Ground {
	public BufferedImage image;//地面图片
	public int x;//x轴坐标
	public int y;//y轴坐标

	public Ground() {
		try {
			x = 0;
			y = 500;
			image = ImageIO.read(getClass().getResource("ground.png"));
		} catch (IOException e) {
			// TODO Auto-generated catch block
			System.out.println("图片未找到");
		}
	}

	//让地面移动
	public void step() {
		x--;
		if(x == -100) {
			x = 0;
		}
	}
}
