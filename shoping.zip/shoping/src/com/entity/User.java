package com.entity;

import java.io.Serializable;

//用户实体类 用于定义用户相关的属性 方便后的数据的封装和传递
public class User implements Serializable {
    private Integer id;
    private String loginname;
    private String username;
    private String password;
    private String sex;
    private Integer type;

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", loginname='" + loginname + '\'' +
                ", username='" + username + '\'' +
                ", password='" + password + '\'' +
                ", sex='" + sex + '\'' +
                ", type=" + type +
                '}';
    }

    public User(Integer id, String loginname, String username, String password, String sex, Integer type) {
        this.id = id;
        this.loginname = loginname;
        this.username = username;
        this.password = password;
        this.sex = sex;
        this.type = type;
    }

    public User() {
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLoginname() {
        return loginname;
    }

    public void setLoginname(String loginname) {
        this.loginname = loginname;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getSex() {
        return sex;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }
}
