package com.servlet;

import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "registServlet", value = "/registServlet")
public class registServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //获取注册的所有数据
        String loginname=request.getParameter("loginname");
        String password=request.getParameter("password");
        String username=request.getParameter("username");
        String sex=request.getParameter("sex");
        QueryRunner runner = new QueryRunner(MyJDBCUtil.getDs());
        try {
            int update = runner.update("insert into user values(?,?,?,?,?,?)", null,loginname ,username,password,sex,1);
            if (update>0){
                System.out.println("进入");
                response.sendRedirect("login.jsp");
            }else{
                response.sendRedirect("Regist.jsp");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
