package com.servlet;

import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@WebServlet(name = "addnewsServlet", value = "/addnewsServlet")
public class addnewsServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //添加的处理请求.获取数据
        //1.获取添加的数据值
        String title = request.getParameter("title");
        String content=request.getParameter("content");
        String time=request.getParameter("time");
        System.out.println(title+"..."+content+"..."+time);
        //调用方法把字符串数据转换成date类型
        SimpleDateFormat sdg=new SimpleDateFormat("yyyy/MM/dd");
        try {
            Date date=sdg.parse(time);
            QueryRunner runner = new QueryRunner(MyJDBCUtil.getDs());
            int update = runner.update("insert into news (title,content,time) values(?,?,?)", title, content, date);
            if (update>0){
                //添加成功
                request.setAttribute("msg", "添加成功!");
                request.getRequestDispatcher("showAllNewsServlet").forward(request, response);
            }else{
                //添加失败
                request.setAttribute("msg", "添加失败!");
                request.getRequestDispatcher("showAllNewsServlet").forward(request, response);

            }
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
