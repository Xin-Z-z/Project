package com.servlet;

import com.entity.User;
import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "loginServlet", value = "/loginServlet")
public class loginServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取登录的数据
        String loginname = request.getParameter("loginname");
        String password = request.getParameter("password");
        System.out.println(loginname+"---"+password);
        //2.调用sql查询
        QueryRunner runner = new QueryRunner(MyJDBCUtil.getDs());

        try {
            
            User user = runner.query("select * from user where loginname=?", new BeanHandler<User>(User.class),loginname);
            System.out.println("----"+user);
            //3.判断user对象是否存在
            if(user != null){
                User user2 = runner.query("select password from user where loginname=?",new BeanHandler<User>(User.class),loginname);
                if(!password.equals(user2.getPassword())){
                    request.setAttribute("msg", "密码错误！");
                    System.out.println("----"+user);
                    //说明用户登录失败，重新返回到登录界面 携带错误密码
                    request.getRequestDispatcher("login.jsp").forward(request,response);//请求转发
                }else{
                    //说明用户登录成功！继续当前用户的类型是1普通用户 2管理用户
                    if (user.getType() == 1){
                        HttpSession session = request.getSession();
                        session.setAttribute("user",user);
                        //普通用户, 跳转到前端页面 index.jsp
                        response.sendRedirect("index.jsp");//重定向
                        //普通用户，跳转到前端页面index.jsp
                        //request.getSession().setAttribute("user",user);
                        //response.sendRedirect("index.jsp");//重定向
                    }else{
                        //在跳转到管理员后台页面的时候为了能够在页面中显示用户信息，需要把user对象传递给前端页面
                        HttpSession session = request.getSession();
                        session.setAttribute("user",user);
                        //管理员，跳转到后台页面loginindex.jsp
                        response.sendRedirect("loginindex.jsp");
                    }
                }
            }else{
                //在request对象中存储错误信息返回给前端进行渲染展示
                request.setAttribute("msg", "帐号错误!");
                //说明用户登录失败 重新返回登录页面 携带错误信息
                request.getRequestDispatcher("login.jsp").forward(request, response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        doGet(request,response);
    }
}