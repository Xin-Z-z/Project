package com.servlet;

import com.entity.User;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.HashMap;
import java.util.Map;

@WebServlet(name = "userAjaxServlet", value = "/userAjaxServlet")
public class userAjaxServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取前端发送的请求
        String loginname = request.getParameter("loginname");
        //System.out.println("我获取了你的发送的请求,"+loginname);
        //2.判断账号是否存在，访问数据库
        //创建queryRunner对象，访问数据库
        QueryRunner runner = new QueryRunner(MyJDBCUtil.getDs());
        //3.调用方法进行数据库的查询
        try {
            User user = runner.query("select * from user where loginname=?", new BeanHandler<User>(User.class), loginname);
            //创建map集合容器，用于封装需要返回给前端的数据
            Map<String,Object> map=new HashMap<>();
            //4.判断user是否为null
            if (user!=null){
                //说明之前注册过，在map容器中设置传递给前端的内容
                map.put("msg", "用户已存在,不可用!");
                map.put("flag", true);
            }else{
                //说明之前没有注册过
                map.put("msg", "用户不存在,可用!");
                map.put("flag", false);
            }

            //把map集合容器传递给回调函数
            ObjectMapper om=new ObjectMapper();
            om.writeValue(response.getWriter(), map);

        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
