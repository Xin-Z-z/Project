package com.servlet;

import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

//接收前端发送的修改请求
@WebServlet(name = "updateServlet", value = "/updateServlet")
public class updateServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取前端用户传递的参数
        String id = request.getParameter("id");
        String title = request.getParameter("title");
        String content = request.getParameter("content");
        String time = request.getParameter("time");
        //2.对获取的时间进行类型转换
        SimpleDateFormat sdf=new SimpleDateFormat("yyyy/MM/dd");
        try {
            Date date = sdf.parse(time);
            //3.创建queryrunner对象
            QueryRunner runner=new QueryRunner(MyJDBCUtil.getDs());
            int update=runner.update("update news set title=?,content=?,time=? where id=?",title,content,date,id);
            if (update>0){
                System.out.println("修改成功");
                //跳转到查询所有的请求
                request.getRequestDispatcher("showAllNewsServlet").forward(request,response);
            }else{
                request.getRequestDispatcher("showAllNewsServlet").forward(request,response);
            }
        } catch (ParseException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
