package com.servlet;

import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "deleteServlet", value = "/deleteServlet")
public class deleteServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取需要删除的新闻id
        String id = request.getParameter("id");
//        System.out.println(id+".............");
        //2.创建QueryRunner对象
        QueryRunner runner=new QueryRunner(MyJDBCUtil.getDs());
        try {
            int update = runner.update("delete from news where id=?", id);
            //判断是否删除成功
            if (update>0){
                //直接跳转到查询所有页面
                request.getRequestDispatcher("showAllNewsServlet").forward(request,response);
            }else{
                //直接跳转到查询所有页面
                request.getRequestDispatcher("showAllNewsServlet").forward(request,response);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
