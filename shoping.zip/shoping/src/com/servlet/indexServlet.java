package com.servlet;

import com.entity.News;
import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanListHandler;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

//获取主页需要显示的数据内容 要想跳转到index.jsp页面 必须先访问此请求
@WebServlet(name = "indexServlet", value = "/indexServlet")
public class indexServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取新闻信息
        QueryRunner runner = new QueryRunner(MyJDBCUtil.getDs());
        try {
            List<News> newsList = runner.query("SELECT * FROM news ORDER BY id DESC LIMIT 0,5", new BeanListHandler<News>(News.class));
            request.setAttribute("newsList",newsList);
            request.getRequestDispatcher("index.jsp").forward(request,response);
        } catch (SQLException e) {
            e.printStackTrace();
        }
        //2.获取商品信息

        //3.获取分类信息
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
