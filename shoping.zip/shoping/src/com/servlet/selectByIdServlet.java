package com.servlet;

import com.entity.News;
import com.utils.MyJDBCUtil;
import org.apache.commons.dbutils.QueryRunner;
import org.apache.commons.dbutils.handlers.BeanHandler;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet(name = "selectByIdServlet", value = "/selectByIdServlet")
public class selectByIdServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        //1.获取查询的新闻id
        String id = request.getParameter("id");
        //2.创建对象
        QueryRunner runner=new QueryRunner(MyJDBCUtil.getDs());
        //3.调用发放
        try {
            News news = runner.query("select * from news where id=?", new BeanHandler<News>(News.class), id);
            //System.out.println("news:"+news);
            //4.把查询到的数据设置在request域中传递给前端进行渲染
            request.setAttribute("news",news);
            //5.页面跳转
            request.getRequestDispatcher("updateNews.jsp").forward(request,response);
        } catch (SQLException e) {
            e.printStackTrace();
        }

    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        doGet(request,response);
    }
}
