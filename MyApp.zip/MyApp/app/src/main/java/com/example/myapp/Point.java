package com.example.myapp;

public class Point {

    public double lon;
    public double lat;
    static int a;

    public Point() {
    }

    public Point(double lon, double lat) {
        this.lon = lon;
        this.lat = lat;
    }

    public double getLon() {
        return this.lon;
    }
    public void setLon(double lon) {
        this.lon = lon;
    }
    public double getLat() {
        return this.lat;
    }

    public void setLat(double lat) {
        this.lat = lat;
    }

    public void aaa() {
        System.out.print(this.lon + "   ");
        System.out.println(this.lat);
    }

    public static Point[] delete1(Point[] point, int[] ints) {

        Point[] points = new Point[point.length];
        int i;

        for(i = 0; i < point.length; ++i) {
            if (i == ints[0]) {
                point[i] = null;
            }

            if (i == ints[1]) {
                point[i] = null;
            }

            if (i == ints[2]) {
                point[i] = null;
            }
        }

        for(i = 0; i < points.length; ++i) {
            points[i] = point[i];
        }
        return points;
    }

    public static Point[] delete2(Point[] points1, Point[] points2) {

        Point[] points = new Point[points1.length];
        int i;

        for(i = 0; i < points1.length; ++i) {
            if (points2[1] == points1[i]) {
                points1[i] = null;
            }
        }

        for(i = 0; i < points.length; ++i) {
            points[i] = points1[i];
        }
        return points;
    }

    public static Point[] append1(Point[] point1, Point[] point2) {

        Point[] points = new Point[point1.length + 1];
        int i;

        if (point2[2] == point1[point1.length - 1]) {
            for(i = 0; i < point1.length - 1; ++i) {
                points[i] = point1[i];
            }

            points[points.length - 2] = point2[2];
            points[points.length - 1] = point2[1];

        } else {
            for(i = 0; i < point1.length; ++i) {
                Point points1 = point2[0];
                Point points2 = point1[i];
                if (points1 == points2) {
                    int z;
                    for(z = 0; z < i; ++z) {
                        points[z] = point1[z];
                    }

                    points[i] = point2[0];
                    points[i + 1] = point2[1];
                    points[i + 2] = point2[2];

                    for(z = i + 3; z < points.length; ++z) {
                        points[z] = point1[z - 1];
                    }
                }
            }
        }

            return points;
        }

    public static Point[] append2(Point[] point1, Point[] point2, int q) {

        Point[] points = new Point[point1.length];
        int i;

        if (point2[2] == point1[q - 1]) {
            for(i = 0; i < q - 1; ++i) {
                points[i] = point1[i];
            }

            points[q - 2] = point2[2];
            points[q - 1] = point2[1];

        } else {
            for(i = 0; i < q; ++i) {
                Point points1 = point2[0];
                Point points2 = point1[i];
                if (points1 == points2) {
                    int z;
                    for(z = 0; z < i; ++z) {
                        points[z] = point1[z];
                    }

                    points[i] = point2[0];
                    points[i + 1] = point2[1];
                    points[i + 2] = point2[2];

                    for(z = i + 3; z < points.length; ++z) {
                        points[z] = point1[z - 1];
                    }
                }
            }
        }
        return points;
    }
}
