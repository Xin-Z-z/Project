package com.example.myapp;

public class Interaction {

    public String[] dispose(int[] ints) {

        ArrayDatabase ad = new ArrayDatabase();
        Point[] points = ad.P();
        String[] strings = ad.S();
        int a = 0;

        for (int i = 0;i < ints.length;i++) {
            if (ints[i] == 1) {
                a++;
            }
        }

        int[] ints1 = new int[a];
        int b = 0;

        for (int i = 0;i < ints.length;i++) {
            if (ints[i] == 1) {
                ints1[b] = i;
                b++;
            }
        }

        Point[] points1 = new Point[a];

        for (int i = 0;i < ints1.length;i++) {
            points1[i] = points[ints1[i]];
        }

        Point[] points2 = MainAlgorithm.algorithm1(points1);
        Point[] points3 = MainAlgorithm.algorithm2(points1,points2);

        int[] ints2 = new int[a];

        for (int i = 0;i < points3.length;i++) {
            for (int j = 0;j < points.length;j++) {
                if (points[j] == points3[i]) {
                    ints2[i] = j;
                }
            }
        }

        String[] strings1 = new String[a];
        for (int i = 0;i < ints2.length;i++) {
            strings1[i] = strings[ints2[i]];
        }
        return strings1;
    }
}
