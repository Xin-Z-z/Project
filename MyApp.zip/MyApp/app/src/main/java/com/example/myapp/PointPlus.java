package com.example.myapp;

public class PointPlus {

    public Point A1;
    public Point A2;

    public PointPlus() {
    }

    public PointPlus(Point A1, Point A2) {
        this.A1 = A1;
        this.A2 = A2;
    }

    public Point getA1() {
        return A1;
    }
    public void setA1(Point a1) {
        A1 = a1;
    }
    public Point getA2() {
        return A2;
    }
    public void setA2(Point a2) {
        A2 = a2;
    }

    //把点存成线
    public static PointPlus[] lineGather1(Point[] point) {

        PointPlus[] pointPluses = new PointPlus[point.length];

        for(int i = 0;i < point.length - 1;i++) {
            int a = i + 1;
            PointPlus pointPlus1 = new PointPlus(point[i],point[a]);
            pointPluses[i] = pointPlus1;
        }
        PointPlus pointPlus2 = new PointPlus(point[point.length - 1],point[0]);
        pointPluses[point.length - 1] = pointPlus2;
        return pointPluses;
    }

    public static PointPlus[] lineGather2(Point[] point) {

        PointPlus[] pointPluses = new PointPlus[point.length];
        int s = 0;

        for (int i = 0;i < point.length - 1;i++) {
            if (point[i] != null) {
                s = i + 1;
            }
        }

        for(int i = 0;i < s - 1;i++) {
            int a = i + 1;
            PointPlus pointPlus1 = new PointPlus(point[i],point[a]);
            pointPluses[i] = pointPlus1;
        }
        PointPlus pointPlus2 = new PointPlus(point[s - 1],point[0]);
        pointPluses[s - 1] = pointPlus2;
        return pointPluses;
    }
}
