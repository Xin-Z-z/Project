package com.example.myapp;

import java.text.DecimalFormat;
import java.util.Arrays;

public class Utility {

    //1.1求两地点之间的距离(用于1.2cirdistance)
    public double distance(Point A,Point B) {

        double R, lat1, lat2, lat, lon, c, sa, sb;
        //地球半径
        R = 6378137;
        lat1 = A.getLat() * Math.PI / 180.0;
        lat2 = B.getLat() * Math.PI / 180.0;
        lat = lat1 - lat2;
        lon = (A.getLon() - B.getLon()) * Math.PI / 180.0;
        sa = Math.sin(lat / 2.0);
        sb = Math.sin(lon / 2.0);
        c = 2 * R * Math.asin(Math.sqrt(sa * sa + Math.cos(lat1) * Math.cos(lat2) * sb * sb));
        return c;
    }

    //1.2循环求距离(调用得以得出)
    public double[] cirdistance(Point[] point) {
        double double1;
        Point point1 = point[0];
        double[] doubles = new double[point.length - 1];
        for(int i = 1;i < point.length;i++) {
            doubles[i - 1] = distance(point1,point[i]);
        }
        return doubles;
    }

    //1.3.-比较得最长距离
    public double compare(double distance1, double distance2) {
        double compare = (distance1 >= distance2) ? distance1 : distance2;
        return compare;
    }

    //1.3遍历最长距离
    public int[] circulation(double[] distance) {

        double[] dis = distance;
        int[] longdis = new int[3];
        int longth1 = 0; //最长距离
        int longth2 = 0; //第二长距离

        for (int i = 0;i < distance.length - 1;i++) {
            double com = compare(dis[i],dis[i+1]);
            if (longth1 < com) {
                longth2 = longth1;
                longth1 = i + 1;
            }
        }
        longdis[0] = 0;
        longdis[1] = longth1 + 1;
        longdis[2] = longth2 + 1;
        return longdis;
    }

    //1.4提取出起点和最远两点成环，存于数组
    public Point[] longestPoint(Point[] points, int[] ints) {

        Point[] points1 = new Point[3];
        points1[0] = points[ints[0]];
        points1[1] = points[ints[1]];
        points1[2] = points[ints[2]];
        return points1;
    }

    //2.1.-判断是否是钝角三角形
    private boolean isObtuseTriangle(double a, double b, double c) {
        // 如果一个三角形的最长边平方>其他两边的平方和，这个三角形是钝角三角形
        double[] doubles = new double[]{a, b, c};
        Arrays.sort(doubles);
        return doubles[2] * doubles[2] > doubles[1] * doubles[1] + doubles[0] * doubles[0];
    }

    //2.1求第三点P到AB直线的距离(海伦公式)
    public double tall(Point A, Point B, Point P) {
        //计算出三边长
        double AB = distance(A, B);
        double AP = distance(A, P);
        double BP = distance(B, P);

        //保留4位小数
        DecimalFormat df = new DecimalFormat("#0.0000");

        double S = (AB + AP + BP) / 2;

        //求面积
        double area = Math.sqrt(S * (S - AB) * (S - AP) * (S - BP));

        //如果点P对应的边长，无限趋近于0，则取长度为AP BP中最小的
        if(AB == 0) {
            return Double.compare(AP, BP) > 0 ? BP : AP;
        }

        //如果不是三角形(在AB线上，距离为0)，则返回0.0000
        if (Double.isNaN(area)) {
            return (double) 0.0000;
        }

        //如果是钝角三角形，且最长边不是点 P 对应的边，则取与船的两条边长中的最短一条
        if (isObtuseTriangle(AB, AP, BP) && (AB < AP || AB < BP)) {
            return Math.min(BP,AP);
        }

        //正常情况：P 点到 AB 的距离 = S * 2 / AB
        return Double.parseDouble(df.format(area * 2 / AB));

    }

    //2.2遍历最短点到线距离及循环出最近距离中最大值
    public Point[] longestTall1(Point[] p1, PointPlus[] p2) {

        double tall1 = 100000000; //最短距离
        double tall2 = 0;
        Point[] points1 = new Point[2];
        Point[] points2 = new Point[3];


        for (int i = 0;i < p1.length;i++) {
            if (p1[i] != null) {
                Point points4 = p1[i];

                for (int j = 0; j < p2.length; j++) {
                    if (p1[i] != null) {
                        PointPlus p3 = p2[j];
                        Point p4 = p3.A1;
                        Point p5 = p3.A2;

                        double tall3 = tall(points4, p4, p5);

                        if (tall1 > tall3) {

                            tall1 = tall3;
                            points1[0] = p4;
                            points1[1] = p5;
                        }
                    }
                }
                if (tall2 < tall1) {
                    points2[0] = points1[0];
                    points2[1] = p1[i];
                    points2[2] = points1[1];
                }
            }
        }
        return points2;
    }

    //2.2遍历最短点到线距离及循环出最近距离中最大值
    public Point[] longestTall2(Point[] p1, PointPlus[] p2) {

        double tall1 = 100000000; //最短距离
        double tall2 = 0;
        Point[] points1 = new Point[3];
        Point[] points2 = new Point[3];


        for (int i = 0;i < p1.length;i++) {
            if (p1[i] != null){
                Point points4 = p1[i];

                for (int j = 0;j < p2.length;j++) {
                    if (p2[j] != null){
                        PointPlus p3 = p2[j];
                        Point p4 = p3.A1;
                        Point p5 = p3.A2;

                        double tall3 = tall(p4, p5, points4);

                        if (tall1 > tall3) {

                            tall1 = tall3;

                            points2[0] = p4;
                            points2[1] = p1[i];
                            points2[2] = p5;
                        }
                    }
                }
            }
        }
        return points2;
    }
}
