package com.example.myapp;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.PersistableBundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class Activity1 extends Activity {

    private TextView but0,but1,but2,but3,but4,but5,but6,but7,but8,but9,but10,
            but11,but12,but13,but14,but15,but16,but17,but18,but19,but20,
            but21,but22,but23,but24,but25,but26,but27,but28,but29,but30,
            but31,but32,but33,but34,but35,but36,but37,but38,but39,but40,
            but41,but42,but43,but44,but45,but46,but47,but48,but49,but50,
            but51,but52,but53,but54,but55,but56,but57,but58,but59,but60,
            but61,but62,but63,but64,but65,but66,but67,but68,but69,but70,
            but71,but72,but73,but74,but75,but76,but77,but78,but79,but80,
            but81,but82,but83,but84,but85,but86,but87,but88,but89,but90,
            but91,but92,but93,but94,but95,but96,but97,but98,but99,but100,
            but101,but102,but103,but104,but105,but001;

    int[] ints = new int[105];

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity);

        but0 = (TextView) findViewById(R.id.a0);
        but1 = (TextView) findViewById(R.id.a1);
        but2 = (TextView) findViewById(R.id.a2);
        but3 = (TextView) findViewById(R.id.a3);
        but4 = (TextView) findViewById(R.id.a4);
        but5 = (TextView) findViewById(R.id.a5);
        but6 = (TextView) findViewById(R.id.a6);
        but7 = (TextView) findViewById(R.id.a7);
        but8 = (TextView) findViewById(R.id.a8);
        but9 = (TextView) findViewById(R.id.a9);
        but10 = (TextView) findViewById(R.id.a10);
        but11 = (TextView) findViewById(R.id.a11);
        but12 = (TextView) findViewById(R.id.a12);
        but13 = (TextView) findViewById(R.id.a13);
        but14 = (TextView) findViewById(R.id.a14);
        but15 = (TextView) findViewById(R.id.a15);
        but16 = (TextView) findViewById(R.id.a16);
        but17 = (TextView) findViewById(R.id.a17);
        but18 = (TextView) findViewById(R.id.a18);
        but19 = (TextView) findViewById(R.id.a19);
        but20 = (TextView) findViewById(R.id.a20);
        but21 = (TextView) findViewById(R.id.a21);
        but22 = (TextView) findViewById(R.id.a22);
        but23 = (TextView) findViewById(R.id.a23);
        but24 = (TextView) findViewById(R.id.a24);
        but25 = (TextView) findViewById(R.id.a25);
        but26 = (TextView) findViewById(R.id.a26);
        but27 = (TextView) findViewById(R.id.a27);
        but28 = (TextView) findViewById(R.id.a28);
        but29 = (TextView) findViewById(R.id.a29);
        but30 = (TextView) findViewById(R.id.a30);
        but31 = (TextView) findViewById(R.id.a31);
        but32 = (TextView) findViewById(R.id.a32);
        but33 = (TextView) findViewById(R.id.a33);
        but34 = (TextView) findViewById(R.id.a34);
        but35 = (TextView) findViewById(R.id.b1);
        but36 = (TextView) findViewById(R.id.b2);
        but37 = (TextView) findViewById(R.id.b3);
        but38 = (TextView) findViewById(R.id.b4);
        but39 = (TextView) findViewById(R.id.b5);
        but40 = (TextView) findViewById(R.id.b6);
        but41 = (TextView) findViewById(R.id.b7);
        but42 = (TextView) findViewById(R.id.b8);
        but43 = (TextView) findViewById(R.id.b9);
        but44 = (TextView) findViewById(R.id.b10);
        but45 = (TextView) findViewById(R.id.b11);
        but46 = (TextView) findViewById(R.id.b12);
        but47 = (TextView) findViewById(R.id.b13);
        but48 = (TextView) findViewById(R.id.b14);
        but49 = (TextView) findViewById(R.id.b15);
        but50 = (TextView) findViewById(R.id.b16);
        but51 = (TextView) findViewById(R.id.b17);
        but52 = (TextView) findViewById(R.id.b18);
        but53 = (TextView) findViewById(R.id.b19);
        but54 = (TextView) findViewById(R.id.b20);
        but55 = (TextView) findViewById(R.id.b21);
        but56 = (TextView) findViewById(R.id.b22);
        but57 = (TextView) findViewById(R.id.b23);
        but58 = (TextView) findViewById(R.id.b24);
        but59 = (TextView) findViewById(R.id.b25);
        but60 = (TextView) findViewById(R.id.b26);
        but61 = (TextView) findViewById(R.id.b27);
        but62 = (TextView) findViewById(R.id.b28);
        but63 = (TextView) findViewById(R.id.b29);
        but64 = (TextView) findViewById(R.id.b30);
        but65 = (TextView) findViewById(R.id.b31);
        but66 = (TextView) findViewById(R.id.b32);
        but67 = (TextView) findViewById(R.id.b33);
        but68 = (TextView) findViewById(R.id.b34);
        but69 = (TextView) findViewById(R.id.b35);
        but70 = (TextView) findViewById(R.id.b36);
        but71 = (TextView) findViewById(R.id.b37);
        but72 = (TextView) findViewById(R.id.b38);
        but73 = (TextView) findViewById(R.id.b39);
        but74 = (TextView) findViewById(R.id.b40);
        but75 = (TextView) findViewById(R.id.b41);
        but76 = (TextView) findViewById(R.id.b42);
        but77 = (TextView) findViewById(R.id.b43);
        but78 = (TextView) findViewById(R.id.b44);
        but79 = (TextView) findViewById(R.id.b45);
        but80 = (TextView) findViewById(R.id.b46);
        but81 = (TextView) findViewById(R.id.b47);
        but82 = (TextView) findViewById(R.id.b48);
        but83 = (TextView) findViewById(R.id.b49);
        but84 = (TextView) findViewById(R.id.b50);
        but85 = (TextView) findViewById(R.id.b51);
        but86 = (TextView) findViewById(R.id.b52);
        but87 = (TextView) findViewById(R.id.b53);
        but88 = (TextView) findViewById(R.id.b54);
        but89 = (TextView) findViewById(R.id.b55);
        but90 = (TextView) findViewById(R.id.b56);
        but91 = (TextView) findViewById(R.id.b57);
        but92 = (TextView) findViewById(R.id.b58);
        but93 = (TextView) findViewById(R.id.b59);
        but94 = (TextView) findViewById(R.id.b60);
        but95 = (TextView) findViewById(R.id.b61);
        but96 = (TextView) findViewById(R.id.b62);
        but97 = (TextView) findViewById(R.id.b63);
        but98 = (TextView) findViewById(R.id.b64);
        but99 = (TextView) findViewById(R.id.b65);
        but100 = (TextView) findViewById(R.id.b66);
        but101 = (TextView) findViewById(R.id.b67);
        but102 = (TextView) findViewById(R.id.b68);
        but103 = (TextView) findViewById(R.id.b69);
        but104 = (TextView) findViewById(R.id.b70);
        but105 = (TextView) findViewById(R.id.b71);
        but001 = (TextView) findViewById(R.id.wancheng);

        but1.setOnClickListener(new myOnClicklistener());
        but2.setOnClickListener(new myOnClicklistener());
        but3.setOnClickListener(new myOnClicklistener());
        but4.setOnClickListener(new myOnClicklistener());
        but5.setOnClickListener(new myOnClicklistener());
        but6.setOnClickListener(new myOnClicklistener());
        but7.setOnClickListener(new myOnClicklistener());
        but8.setOnClickListener(new myOnClicklistener());
        but9.setOnClickListener(new myOnClicklistener());
        but10.setOnClickListener(new myOnClicklistener());
        but11.setOnClickListener(new myOnClicklistener());
        but12.setOnClickListener(new myOnClicklistener());
        but13.setOnClickListener(new myOnClicklistener());
        but14.setOnClickListener(new myOnClicklistener());
        but15.setOnClickListener(new myOnClicklistener());
        but16.setOnClickListener(new myOnClicklistener());
        but17.setOnClickListener(new myOnClicklistener());
        but18.setOnClickListener(new myOnClicklistener());
        but19.setOnClickListener(new myOnClicklistener());
        but20.setOnClickListener(new myOnClicklistener());
        but21.setOnClickListener(new myOnClicklistener());
        but22.setOnClickListener(new myOnClicklistener());
        but23.setOnClickListener(new myOnClicklistener());
        but24.setOnClickListener(new myOnClicklistener());
        but25.setOnClickListener(new myOnClicklistener());
        but26.setOnClickListener(new myOnClicklistener());
        but27.setOnClickListener(new myOnClicklistener());
        but28.setOnClickListener(new myOnClicklistener());
        but29.setOnClickListener(new myOnClicklistener());
        but30.setOnClickListener(new myOnClicklistener());
        but31.setOnClickListener(new myOnClicklistener());
        but32.setOnClickListener(new myOnClicklistener());
        but33.setOnClickListener(new myOnClicklistener());
        but34.setOnClickListener(new myOnClicklistener());
        but35.setOnClickListener(new myOnClicklistener());
        but36.setOnClickListener(new myOnClicklistener());
        but37.setOnClickListener(new myOnClicklistener());
        but38.setOnClickListener(new myOnClicklistener());
        but39.setOnClickListener(new myOnClicklistener());
        but40.setOnClickListener(new myOnClicklistener());
        but41.setOnClickListener(new myOnClicklistener());
        but42.setOnClickListener(new myOnClicklistener());
        but43.setOnClickListener(new myOnClicklistener());
        but41.setOnClickListener(new myOnClicklistener());
        but42.setOnClickListener(new myOnClicklistener());
        but43.setOnClickListener(new myOnClicklistener());
        but44.setOnClickListener(new myOnClicklistener());
        but45.setOnClickListener(new myOnClicklistener());
        but46.setOnClickListener(new myOnClicklistener());
        but47.setOnClickListener(new myOnClicklistener());
        but48.setOnClickListener(new myOnClicklistener());
        but49.setOnClickListener(new myOnClicklistener());
        but50.setOnClickListener(new myOnClicklistener());
        but51.setOnClickListener(new myOnClicklistener());
        but52.setOnClickListener(new myOnClicklistener());
        but53.setOnClickListener(new myOnClicklistener());
        but54.setOnClickListener(new myOnClicklistener());
        but55.setOnClickListener(new myOnClicklistener());
        but56.setOnClickListener(new myOnClicklistener());
        but57.setOnClickListener(new myOnClicklistener());
        but58.setOnClickListener(new myOnClicklistener());
        but59.setOnClickListener(new myOnClicklistener());
        but60.setOnClickListener(new myOnClicklistener());
        but61.setOnClickListener(new myOnClicklistener());
        but62.setOnClickListener(new myOnClicklistener());
        but63.setOnClickListener(new myOnClicklistener());
        but64.setOnClickListener(new myOnClicklistener());
        but65.setOnClickListener(new myOnClicklistener());
        but66.setOnClickListener(new myOnClicklistener());
        but67.setOnClickListener(new myOnClicklistener());
        but68.setOnClickListener(new myOnClicklistener());
        but69.setOnClickListener(new myOnClicklistener());
        but70.setOnClickListener(new myOnClicklistener());
        but71.setOnClickListener(new myOnClicklistener());
        but72.setOnClickListener(new myOnClicklistener());
        but73.setOnClickListener(new myOnClicklistener());
        but74.setOnClickListener(new myOnClicklistener());
        but75.setOnClickListener(new myOnClicklistener());
        but76.setOnClickListener(new myOnClicklistener());
        but77.setOnClickListener(new myOnClicklistener());
        but78.setOnClickListener(new myOnClicklistener());
        but79.setOnClickListener(new myOnClicklistener());
        but80.setOnClickListener(new myOnClicklistener());
        but81.setOnClickListener(new myOnClicklistener());
        but82.setOnClickListener(new myOnClicklistener());
        but83.setOnClickListener(new myOnClicklistener());
        but84.setOnClickListener(new myOnClicklistener());
        but85.setOnClickListener(new myOnClicklistener());
        but86.setOnClickListener(new myOnClicklistener());
        but87.setOnClickListener(new myOnClicklistener());
        but88.setOnClickListener(new myOnClicklistener());
        but89.setOnClickListener(new myOnClicklistener());
        but90.setOnClickListener(new myOnClicklistener());
        but91.setOnClickListener(new myOnClicklistener());
        but92.setOnClickListener(new myOnClicklistener());
        but93.setOnClickListener(new myOnClicklistener());
        but94.setOnClickListener(new myOnClicklistener());
        but95.setOnClickListener(new myOnClicklistener());
        but96.setOnClickListener(new myOnClicklistener());
        but97.setOnClickListener(new myOnClicklistener());
        but98.setOnClickListener(new myOnClicklistener());
        but99.setOnClickListener(new myOnClicklistener());
        but100.setOnClickListener(new myOnClicklistener());
        but101.setOnClickListener(new myOnClicklistener());
        but102.setOnClickListener(new myOnClicklistener());
        but103.setOnClickListener(new myOnClicklistener());
        but104.setOnClickListener(new myOnClicklistener());
        but105.setOnClickListener(new myOnClicklistener());
        but001.setOnClickListener(new myOnClicklistener());
    }

    class myOnClicklistener implements View.OnClickListener {
        @Override
        public void onClick(View v) {
            switch(v.getId()){
                case R.id.a1:
                    ints[0] = 1;
                    String str0=but0.getText().toString();
                    str0+="北京市 - ";
                    but0.setText(str0);
                    break;
                case R.id.a2:
                    ints[1] = 1;
                    String str1=but0.getText().toString();
                    str1+="上海市 - ";
                    but0.setText(str1);
                    break;
                case R.id.a3:
                    ints[2] = 1;
                    String str2=but0.getText().toString();
                    str2+="广州市 - ";
                    but0.setText(str2);
                    break;
                case R.id.a4:
                    ints[3] = 1;
                    String str3=but0.getText().toString();
                    str3+="深圳市 - ";
                    but0.setText(str3);
                    break;
                case R.id.a5:
                    ints[4] = 1;
                    String str4=but0.getText().toString();
                    str4+="合肥市 - ";
                    but0.setText(str4);
                    break;
                case R.id.a6:
                    ints[5] = 1;
                    String str5=but0.getText().toString();
                    str5+="福州市 - ";
                    but0.setText(str5);
                    break;
                case R.id.a7:
                    ints[6] = 1;
                    String str6=but0.getText().toString();
                    str6+="泉州市 - ";
                    but0.setText(str6);
                    break;
                case R.id.a8:
                    ints[7] = 1;
                    String str7=but0.getText().toString();
                    str7+="厦门市 - ";
                    but0.setText(str7);
                    break;
                case R.id.a9:
                    ints[8] = 1;
                    String str8=but0.getText().toString();
                    str8+="兰州市 - ";
                    but0.setText(str8);
                    break;
                case R.id.a10:
                    ints[9] = 1;
                    String str9=but0.getText().toString();
                    str9+="贵阳市 - ";
                    but0.setText(str9);
                    break;
                case R.id.a11:
                    ints[10] = 1;
                    String str10=but0.getText().toString();
                    str10+="珠海市 - ";
                    but0.setText(str10);
                    break;
                case R.id.a12:
                    ints[11] = 1;
                    String str11=but0.getText().toString();
                    str11+="惠州市 - ";
                    but0.setText(str11);
                    break;
                case R.id.a13:
                    ints[12] = 1;
                    String str12=but0.getText().toString();
                    str12+="中山市 - ";
                    but0.setText(str12);
                    break;
                case R.id.a14:
                    ints[13] = 1;
                    String str13=but0.getText().toString();
                    str13+="南宁市 - ";
                    but0.setText(str13);
                    break;
                case R.id.a15:
                    ints[14] = 1;
                    String str14=but0.getText().toString();
                    str14+="石家庄市 - ";
                    but0.setText(str14);
                    break;
                case R.id.a16:
                    ints[15] = 1;
                    String str15=but0.getText().toString();
                    str15+="哈尔滨市 - ";
                    but0.setText(str15);
                    break;
                case R.id.a17:
                    ints[16] = 1;
                    String str16=but0.getText().toString();
                    str16+="长春市 - ";
                    but0.setText(str16);
                    break;
                case R.id.a18:
                    ints[17] = 1;
                    String str17=but0.getText().toString();
                    str17+="常州市 - ";
                    but0.setText(str17);
                    break;
                case R.id.a19:
                    ints[18] = 1;
                    String str18=but0.getText().toString();
                    str18+="南通市 - ";
                    but0.setText(str18);
                    break;
                case R.id.a20:
                    ints[19] = 1;
                    String str19=but0.getText().toString();
                    str19+="无锡市 - ";
                    but0.setText(str19);
                    break;
                case R.id.a21:
                    ints[20] = 1;
                    String str20=but0.getText().toString();
                    str20+="徐州市 - ";
                    but0.setText(str20);
                    break;
                case R.id.a22:
                    ints[21] = 1;
                    String str21=but0.getText().toString();
                    str21+="南昌市 - ";
                    but0.setText(str21);
                    break;
                case R.id.a23:
                    ints[22] = 1;
                    String str22=but0.getText().toString();
                    str22+="大连市 - ";
                    but0.setText(str22);
                    break;
                case R.id.a24:
                    ints[23] = 1;
                    String str23=but0.getText().toString();
                    str23+="潍坊市 - ";
                    but0.setText(str23);
                    break;
                case R.id.a25:
                    ints[24] = 1;
                    String str24=but0.getText().toString();
                    str24+="济南市 - ";
                    but0.setText(str24);
                    break;
                case R.id.a26:
                    ints[25] = 1;
                    String str25=but0.getText().toString();
                    str25+="临沂市 - ";
                    but0.setText(str25);
                    break;
                case R.id.a27:
                    ints[26] = 1;
                    String str26=but0.getText().toString();
                    str26+="烟台市 - ";
                    but0.setText(str26);
                    break;
                case R.id.a28:
                    ints[27] = 1;
                    String str27=but0.getText().toString();
                    str27+="太原市 - ";
                    but0.setText(str27);
                    break;
                case R.id.a29:
                    ints[28] = 1;
                    String str28=but0.getText().toString();
                    str28+="昆明市 - ";
                    but0.setText(str28);
                    break;
                case R.id.a30:
                    ints[29] = 1;
                    String str29=but0.getText().toString();
                    str29+="嘉兴市 - ";
                    but0.setText(str29);
                    break;
                case R.id.a31:
                    ints[30] = 1;
                    String str30=but0.getText().toString();
                    str30+="金华市 - ";
                    but0.setText(str30);
                    break;
                case R.id.a32:
                    ints[31] = 1;
                    String str31=but0.getText().toString();
                    str31+="绍兴市 - ";
                    but0.setText(str31);
                    break;
                case R.id.a33:
                    ints[32] = 1;
                    String str32=but0.getText().toString();
                    str32+="台州市 - ";
                    but0.setText(str32);
                    break;
                case R.id.a34:
                    ints[33] = 1;
                    String str33=but0.getText().toString();
                    str33+="温州市 - ";
                    but0.setText(str33);
                    break;
                case R.id.b1:
                    ints[34] = 1;
                    String str34=but0.getText().toString();
                    str34+="大庆市 - ";
                    but0.setText(str34);
                    break;
                case R.id.b2:
                    ints[35] = 1;
                    String str35=but0.getText().toString();
                    str35+="鞍山市 - ";
                    but0.setText(str35);
                    break;
                case R.id.b3:
                    ints[36] = 1;
                    String str36=but0.getText().toString();
                    str36+="呼和浩特市 - ";
                    but0.setText(str36);
                    break;
                case R.id.b4:
                    ints[37] = 1;
                    String str37=but0.getText().toString();
                    str37+="廊坊市 - ";
                    but0.setText(str37);
                    break;
                case R.id.b5:
                    ints[38] = 1;
                    String str38=but0.getText().toString();
                    str38+="保定市 - ";
                    but0.setText(str38);
                    break;
                case R.id.b6:
                    ints[39] = 1;
                    String str39=but0.getText().toString();
                    str39+="邯郸市 - ";
                    but0.setText(str39);
                    break;
                case R.id.b7:
                    ints[40] = 1;
                    String str40=but0.getText().toString();
                    str40+="邢台市 - ";
                    but0.setText(str40);
                    break;
                case R.id.b8:
                    ints[41] = 1;
                    String str41=but0.getText().toString();
                    str41+="唐山市 - ";
                    but0.setText(str41);
                    break;
                case R.id.b9:
                    ints[42] = 1;
                    String str42=but0.getText().toString();
                    str42+="沧州市 - ";
                    but0.setText(str42);
                    break;
                case R.id.b10:
                    ints[43] = 1;
                    String str43=but0.getText().toString();
                    str43+="秦皇岛市 - ";
                    but0.setText(str43);
                    break;
                case R.id.b11:
                    ints[44] = 1;
                    String str44=but0.getText().toString();
                    str44+="菏泽市 - ";
                    but0.setText(str44);
                    break;
                case R.id.b12:
                    ints[45] = 1;
                    String str45=but0.getText().toString();
                    str45+="德州市 - ";
                    but0.setText(str45);
                    break;
                case R.id.b13:
                    ints[46] = 1;
                    String str46=but0.getText().toString();
                    str46+="淄博市 - ";
                    but0.setText(str46);
                    break;
                case R.id.b14:
                    ints[47] = 1;
                    String str47=but0.getText().toString();
                    str47+="济宁市 - ";
                    but0.setText(str47);
                    break;
                case R.id.b15:
                    ints[48] = 1;
                    String str48=but0.getText().toString();
                    str48+="威海市 - ";
                    but0.setText(str48);
                    break;
                case R.id.b16:
                    ints[49] = 1;
                    String str49=but0.getText().toString();
                    str49+="新乡市 - ";
                    but0.setText(str49);
                    break;
                case R.id.b17:
                    ints[50] = 1;
                    String str50=but0.getText().toString();
                    str50+="驻马店市 - ";
                    but0.setText(str50);
                    break;
                case R.id.b18:
                    ints[51] = 1;
                    String str51=but0.getText().toString();
                    str51+="信阳市 - ";
                    but0.setText(str51);
                    break;
                case R.id.b19:
                    ints[52] = 1;
                    String str52=but0.getText().toString();
                    str52+="商丘市 - ";
                    but0.setText(str52);
                    break;
                case R.id.b20:
                    ints[53] = 1;
                    String str53=but0.getText().toString();
                    str53+="南阳市 - ";
                    but0.setText(str53);
                    break;
                case R.id.b21:
                    ints[54] = 1;
                    String str54=but0.getText().toString();
                    str54+="周口市 - ";
                    but0.setText(str54);
                    break;
                case R.id.b22:
                    ints[55] = 1;
                    String str55=but0.getText().toString();
                    str55+="洛阳市 - ";
                    but0.setText(str55);
                    break;
                case R.id.b23:
                    ints[56] = 1;
                    String str56=but0.getText().toString();
                    str56+="咸阳市 - ";
                    but0.setText(str56);
                    break;
                case R.id.b24:
                    ints[57] = 1;
                    String str57=but0.getText().toString();
                    str57+="银川市 - ";
                    but0.setText(str57);
                    break;
                case R.id.b25:
                    ints[58] = 1;
                    String str58=but0.getText().toString();
                    str58+="乌鲁木齐市 - ";
                    but0.setText(str58);
                    break;
                case R.id.b26:
                    ints[59] = 1;
                    String str59=but0.getText().toString();
                    str59+="绵阳市 - ";
                    but0.setText(str59);
                    break;
                case R.id.b27:
                    ints[60] = 1;
                    String str60=but0.getText().toString();
                    str60+="南充市 - ";
                    but0.setText(str60);
                    break;
                case R.id.b28:
                    ints[61] = 1;
                    String str61=but0.getText().toString();
                    str61+="宜昌市 - ";
                    but0.setText(str61);
                    break;
                case R.id.b29:
                    ints[62] = 1;
                    String str62=but0.getText().toString();
                    str62+="荆州市 - ";
                    but0.setText(str62);
                    break;
                case R.id.b30:
                    ints[63] = 1;
                    String str63=but0.getText().toString();
                    str63+="襄阳市 - ";
                    but0.setText(str63);
                    break;
                case R.id.b31:
                    ints[64] = 1;
                    String str64=but0.getText().toString();
                    str64+="马鞍山市 - ";
                    but0.setText(str64);
                    break;
                case R.id.b32:
                    ints[65] = 1;
                    String str65=but0.getText().toString();
                    str65+="安庆市 - ";
                    but0.setText(str65);
                    break;
                case R.id.b33:
                    ints[66] = 1;
                    String str66=but0.getText().toString();
                    str66+="六安市 - ";
                    but0.setText(str66);
                    break;
                case R.id.b34:
                    ints[67] = 1;
                    String str67=but0.getText().toString();
                    str67+="蚌埠市 - ";
                    but0.setText(str67);
                    break;
                case R.id.b35:
                    ints[68] = 1;
                    String str68=but0.getText().toString();
                    str68+="芜湖市 - ";
                    but0.setText(str68);
                    break;
                case R.id.b36:
                    ints[69] = 1;
                    String str69=but0.getText().toString();
                    str69+="阜阳市 - ";
                    but0.setText(str69);
                    break;
                case R.id.b37:
                    ints[70] = 1;
                    String str70=but0.getText().toString();
                    str70+="滁州市 - ";
                    but0.setText(str70);
                    break;
                case R.id.b38:
                    ints[71] = 1;
                    String str71=but0.getText().toString();
                    str71+="连云港市 - ";
                    but0.setText(str71);
                    break;
                case R.id.b39:
                    ints[72] = 1;
                    String str72=but0.getText().toString();
                    str72+="扬州市 - ";
                    but0.setText(str72);
                    break;
                case R.id.b40:
                    ints[73] = 1;
                    String str73=but0.getText().toString();
                    str73+="泰州市 - ";
                    but0.setText(str73);
                    break;
                case R.id.b41:
                    ints[74] = 1;
                    String str74=but0.getText().toString();
                    str74+="盐城市 - ";
                    but0.setText(str74);
                    break;
                case R.id.b42:
                    ints[75] = 1;
                    String str75=but0.getText().toString();
                    str75+="宿迁市 - ";
                    but0.setText(str75);
                    break;
                case R.id.b43:
                    ints[76] = 1;
                    String str76=but0.getText().toString();
                    str76+="淮安市 - ";
                    but0.setText(str76);
                    break;
                case R.id.b44:
                    ints[77] = 1;
                    String str77=but0.getText().toString();
                    str77+="镇江市 - ";
                    but0.setText(str77);
                    break;
                case R.id.b45:
                    ints[78] = 1;
                    String str78=but0.getText().toString();
                    str78+="宜春市 - ";
                    but0.setText(str78);
                    break;
                case R.id.b46:
                    ints[79] = 1;
                    String str79=but0.getText().toString();
                    str79+="九江市 - ";
                    but0.setText(str79);
                    break;
                case R.id.b47:
                    ints[80] = 1;
                    String str80=but0.getText().toString();
                    str80+="赣州市 - ";
                    but0.setText(str80);
                    break;
                case R.id.b48:
                    ints[81] = 1;
                    String str81=but0.getText().toString();
                    str81+="上饶市 - ";
                    but0.setText(str81);
                    break;
                case R.id.b49:
                    ints[82] = 1;
                    String str82=but0.getText().toString();
                    str82+="舟山市 - ";
                    but0.setText(str82);
                    break;
                case R.id.b50:
                    ints[83] = 1;
                    String str83=but0.getText().toString();
                    str83+="丽水市 - ";
                    but0.setText(str83);
                    break;
                case R.id.b51:
                    ints[84] = 1;
                    String str84=but0.getText().toString();
                    str84+="湖州市 - ";
                    but0.setText(str84);
                    break;
                case R.id.b52:
                    ints[85] = 1;
                    String str85=but0.getText().toString();
                    str85+="衡阳市 - ";
                    but0.setText(str85);
                    break;
                case R.id.b53:
                    ints[86] = 1;
                    String str86=but0.getText().toString();
                    str86+="岳阳市 - ";
                    but0.setText(str86);
                    break;
                case R.id.b54:
                    ints[87] = 1;
                    String str87=but0.getText().toString();
                    str87+="株洲市 - ";
                    but0.setText(str87);
                    break;
                case R.id.b55:
                    ints[88] = 1;
                    String str88=but0.getText().toString();
                    str88+="三明市 - ";
                    but0.setText(str88);
                    break;
                case R.id.b56:
                    ints[89] = 1;
                    String str89=but0.getText().toString();
                    str89+="漳州市 - ";
                    but0.setText(str89);
                    break;
                case R.id.b57:
                    ints[90] = 1;
                    String str90=but0.getText().toString();
                    str90+="宁德市 - ";
                    but0.setText(str90);
                    break;
                case R.id.b58:
                    ints[91] = 1;
                    String str91=but0.getText().toString();
                    str91+="莆田市 - ";
                    but0.setText(str91);
                    break;
                case R.id.b59:
                    ints[92] = 1;
                    String str92=but0.getText().toString();
                    str92+="潮州市 - ";
                    but0.setText(str92);
                    break;
                case R.id.b60:
                    ints[93] = 1;
                    String str93=but0.getText().toString();
                    str93+="汕头市 - ";
                    but0.setText(str93);
                    break;
                case R.id.b61:
                    ints[94] = 1;
                    String str94=but0.getText().toString();
                    str94+="清远市 - ";
                    but0.setText(str94);
                    break;
                case R.id.b62:
                    ints[95] = 1;
                    String str95=but0.getText().toString();
                    str95+="江门市 - ";
                    but0.setText(str95);
                    break;
                case R.id.b63:
                    ints[96] = 1;
                    String str96=but0.getText().toString();
                    str96+="揭阳市 - ";
                    but0.setText(str96);
                    break;
                case R.id.b64:
                    ints[97] = 1;
                    String str97=but0.getText().toString();
                    str97+="茂名市 - ";
                    but0.setText(str97);
                    break;
                case R.id.b65:
                    ints[98] = 1;
                    String str98=but0.getText().toString();
                    str98+="湛江市 - ";
                    but0.setText(str98);
                    break;
                case R.id.b66:
                    ints[99] = 1;
                    String str99=but0.getText().toString();
                    str99+="肇庆市 - ";
                    but0.setText(str99);
                    break;
                case R.id.b67:
                    ints[100] = 1;
                    String str100=but0.getText().toString();
                    str100+="遵义市 - ";
                    but0.setText(str100);
                    break;
                case R.id.b68:
                    ints[101] = 1;
                    String str101=but0.getText().toString();
                    str101+="桂林市 - ";
                    but0.setText(str101);
                    break;
                case R.id.b69:
                    ints[102] = 1;
                    String str102=but0.getText().toString();
                    str102+="柳州市 - ";
                    but0.setText(str102);
                    break;
                case R.id.b70:
                    ints[103] = 1;
                    String str103=but0.getText().toString();
                    str103+="三亚市 - ";
                    but0.setText(str103);
                    break;
                case R.id.b71:
                    ints[104] = 1;
                    String str104=but0.getText().toString();
                    str104+="常德市 - ";
                    but0.setText(str104);
                    break;
                case R.id.wancheng:
                    Interaction interaction = new Interaction();
                    String[] strings = interaction.dispose(ints);
                    String str105=but0.getText().toString();
                    str105 += "|     最终的城市旅行路线为：";
                    but0.setText(str105);
                    for (int i = 0;i < strings.length;i++) {
                        String str106=but0.getText().toString();
                        str106 += strings[i] + " - ";
                        but0.setText(str106);
                    }
                    break;
            }
        }
    }
}