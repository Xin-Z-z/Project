package com.example.myapp;

public class ArrayDatabase {

    public String[] S() {
        String[] strings = new String[]{"北京市","上海市","广州市","深圳市","合肥市",
                "福州市","泉州市","厦门市","兰州市","贵阳市","珠海市","惠州市","中山市",
                "南宁市","石家庄市","哈尔滨市","长春市","常州市","南通市","无锡市",
                "徐州市","南昌市","大连市","潍坊市","济南市","临沂市","烟台市","太原市",
                "昆明市","嘉兴市","金华市","绍兴市","台州市","温州市","大庆市","鞍山市",
                "呼和浩特市","廊坊市","保定市","邯郸市","邢台市","唐山市","沧州市",
                "秦皇岛市","菏泽市","德州市","淄博市","济宁市","威海市","新乡市","驻马店市",
                "信阳市","商丘市","南阳市","周口市","洛阳市","咸阳市","银川市","乌鲁木齐市",
                "绵阳市","南充市","宜昌市","荆州市","襄阳市","马鞍山市","安庆市","六安市",
                "蚌埠市","芜湖市","阜阳市","滁州市","连云港市","扬州市","泰州市","盐城市","宿迁市",
                "淮安市","镇江市","宜春市","九江市","赣州市","上饶市","舟山市","丽水市","湖州市",
                "衡阳市","岳阳市","株洲市","三明市","漳州市","宁德市","莆田市","潮州市","汕头市 ",
                "清远市","江门市","揭阳市","茂名市","湛江市","肇庆市","遵义市","桂林市","柳州市",
                "三亚市","常德市"};
        return strings;
    }

    public Point[] P() {
        Point[] points = new Point[105];

        Point point1 = new Point(116.40,39.90);
        points[0] =point1;
        Point point2 = new Point(121.47,31.23);
        points[1] =point2;
        Point point3 = new Point(113.27,23.13);
        points[2] =point3;
        Point point4 = new Point(114.05,22.55);
        points[3] =point4;
        Point point5 = new Point(117.25,31.83);
        points[4] =point5;
        Point point6 = new Point(119.30,26.08);
        points[5] =point6;
        Point point7 = new Point(118.67,24.88);
        points[6] =point7;
        Point point8 = new Point(118.08,24.48);
        points[7] =point8;
        Point point9 = new Point(103.82,36.07);
        points[8] =point9;
        Point point10 = new Point(106.63,26.65);
        points[9] =point10;
        Point point11 = new Point(113.57,22.27);
        points[10] =point11;
        Point point12 = new Point(114.42,23.12);
        points[11] =point12;
        Point point13 = new Point(113.38,22.52);
        points[12] =point13;
        Point point14 = new Point(108.37,22.82);
        points[13] =point14;
        Point point15 = new Point(114.52,38.05);
        points[14] =point15;
        Point point16 = new Point(126.53,45.80);
        points[15] =point16;
        Point point17 = new Point(125.32,43.90);
        points[16] =point17;
        Point point18 = new Point(119.95,31.78);
        points[17] =point18;
        Point point19 = new Point(120.88,31.98);
        points[18] =point19;
        Point point20 = new Point(120.30,31.57);
        points[19] =point20;
        Point point21 = new Point(117.18,34.27);
        points[20] =point21;
        Point point22 = new Point(115.85,28.68);
        points[21] =point22;
        Point point23 = new Point(121.62,38.92);
        points[22] =point23;
        Point point24 = new Point(119.15,36.70);
        points[23] =point24;
        Point point25 = new Point(116.98,36.67);
        points[24] =point25;
        Point point26 = new Point(118.35,35.05);
        points[25] =point26;
        Point point27 = new Point(121.43,37.45);
        points[26] =point27;
        Point point28 = new Point(112.55,37.87);
        points[27] =point28;
        Point point29 = new Point(102.72,25.05);
        points[28] =point29;
        Point point30 = new Point(120.75,30.75);
        points[29] =point30;
        Point point31 = new Point(119.65,29.08);
        points[30] =point31;
        Point point32 = new Point(120.57,30.00);
        points[31] =point32;
        Point point33 = new Point(121.43,28.68);
        points[32] =point33;
        Point point34 = new Point(120.70,28.00);
        points[33] =point34;
        Point point35 = new Point(125.03,46.58);
        points[34] =point35;
        Point point36 = new Point(122.98,41.10);
        points[35] =point36;
        Point point37 = new Point(111.73,40.83);
        points[36] =point37;
        Point point38 = new Point(116.70,39.52);
        points[37] =point38;
        Point point39 = new Point(115.47,38.87);
        points[38] =point39;
        Point point40 = new Point(114.48,36.62);
        points[39] =point40;
        Point point41 = new Point(114.48,37.07);
        points[40] =point41;
        Point point42 = new Point(118.20,39.63);
        points[41] =point42;
        Point point43 = new Point(116.83,38.30);
        points[42] =point43;
        Point point44 = new Point(119.60,39.93);
        points[43] =point44;
        Point point45 = new Point(115.46,35.25);
        points[44] =point45;
        Point point46 = new Point(116.30,37.45);
        points[45] =point46;
        Point point47 = new Point(118.05,36.82);
        points[46] =point47;
        Point point48 = new Point(116.58,35.42);
        points[47] =point48;
        Point point49 = new Point(122.12,37.52);
        points[48] =point49;
        Point point50 = new Point(113.90,35.30);
        points[49] =point50;
        Point point51 = new Point(114.02,32.98);
        points[50] =point51;
        Point point52 = new Point(114.07,32.13);
        points[51] =point52;
        Point point53 = new Point(115.65,34.45);
        points[52] =point53;
        Point point54 = new Point(112.52,33.00);
        points[53] =point54;
        Point point55 = new Point(114.65,33.62);
        points[54] =point55;
        Point point56 = new Point(112.45,34.62);
        points[55] =point56;
        Point point57 = new Point(108.70,34.33);
        points[56] =point57;
        Point point58 = new Point(106.28,38.47);
        points[57] =point58;
        Point point59 = new Point(87.62,43.82);
        points[58] =point59;
        Point point60 = new Point(104.73,31.47);
        points[59] =point60;
        Point point61 = new Point(106.08,30.78);
        points[60] =point61;
        Point point62 = new Point(111.28,30.70);
        points[61] =point62;
        Point point63 = new Point(112.23,30.33);
        points[62] =point63;
        Point point64 = new Point(112.14,32.05);
        points[63] =point64;
        Point point65 = new Point(118.50,31.70);
        points[64] =point65;
        Point point66 = new Point(117.05,30.53);
        points[65] =point66;
        Point point67 = new Point(116.50,31.77);
        points[66] =point67;
        Point point68 = new Point(117.38,32.92);
        points[67] =point68;
        Point point69 = new Point(118.38,31.33);
        points[68] =point69;
        Point point70 = new Point(115.82,32.90);
        points[69] =point70;
        Point point71 = new Point(118.32,32.30);
        points[70] =point71;
        Point point72 = new Point(119.22,34.60);
        points[71] =point72;
        Point point73 = new Point(119.40,32.40);
        points[72] =point73;
        Point point74 = new Point(119.92,32.45);
        points[73] =point74;
        Point point75 = new Point(120.15,33.35);
        points[74] =point75;
        Point point76 = new Point(118.28,33.97);
        points[75] =point76;
        Point point77 = new Point(119.02,33.62);
        points[76] =point77;
        Point point78 = new Point(119.45,32.20);
        points[77] =point78;
        Point point79 = new Point(114.38,27.80);
        points[78] =point79;
        Point point80 = new Point(116.00,29.70);
        points[79] =point80;
        Point point81 = new Point(114.93,25.83);
        points[80] =point81;
        Point point82 = new Point(117.97,28.45);
        points[81] =point82;
        Point point83 = new Point(122.20,30.00);
        points[82] =point83;
        Point point84 = new Point(119.92,28.45);
        points[83] =point84;
        Point point85 = new Point(120.08,30.90);
        points[84] =point85;
        Point point86 = new Point(112.57,26.90);
        points[85] =point86;
        Point point87 = new Point(113.12,29.37);
        points[86] =point87;
        Point point88 = new Point(113.13,27.83);
        points[87] =point88;
        Point point89 = new Point(117.62,26.27);
        points[88] =point89;
        Point point90 = new Point(117.65,24.52);
        points[89] =point90;
        Point point91 = new Point(119.52,26.67);
        points[90] =point91;
        Point point92 = new Point(119.00,25.43);
        points[91] =point92;
        Point point93 = new Point(116.62,23.67);
        points[92] =point93;
        Point point94 = new Point(116.68,23.35);
        points[93] =point94;
        Point point95 = new Point(113.03,23.70);
        points[94] =point95;
        Point point96 = new Point(113.08,22.58);
        points[95] =point96;
        Point point97 = new Point(116.37,23.55);
        points[96] =point97;
        Point point98 = new Point(110.92,21.67);
        points[97] =point98;
        Point point99 = new Point(110.35,21.27);
        points[98] =point99;
        Point point100 = new Point(112.47,23.05);
        points[99] =point100;
        Point point101 = new Point(106.92,27.73);
        points[100] =point101;
        Point point102 = new Point(110.28,25.28);
        points[101] =point102;
        Point point103 = new Point(109.42,24.33);
        points[102] =point103;
        Point point104 = new Point(109.50,18.25);
        points[103] =point104;
        Point point105 = new Point(111.68,29.05);
        points[104] =point105;

        return points;
    }
}
