package com.example.myapp;

public class MainAlgorithm {

    static int[] ints = new int[3];

    //第一部分
    public static Point[] algorithm1(Point[] points) {

        Utility utility = new Utility();

        double[] doubles = utility.cirdistance(points);

        int[] ints = utility.circulation(doubles);

        MainAlgorithm.ints = ints;

        Point[] points1 = utility.longestPoint(points,ints);

        return points1; //返回的值用于生成PointPlus[]数组
    }

    //第二部分
    public static Point[] algorithm2(Point[] points1, Point[] points2) { //points1完整数组，points2是第一部分返回的值

        Point[] points = Point.delete1(points1,MainAlgorithm.ints); //生成剩余点Point[]数组

        PointPlus[] pointPluses  = PointPlus.lineGather1(points2); // 生成PointPlus[]数组

        Utility utility = new Utility();

        Point[] points3 = new Point[points1.length]; //收集排序后的点

        PointPlus[] pointPluses1 = new PointPlus[points1.length]; //排序后的点成线

        Point[] points4 = new Point[points1.length]; //收集剩余的点

        for (int i = 0;i < points.length - 3;i++) {

            if(i == 0) {

                Point[] points5 = utility.longestTall1(points,pointPluses);
                Point[] points6 = Point.append1(points2,points5);
                Point[] points7 = Point.delete2(points,points5);

                for (int j = 0;j < points6.length;j++) {
                    points3[j] = points6[j];
                }

                for (int j = 0;j < points7.length;j++) {
                    points4[j] = points7[j];
                }

                PointPlus[] pointPluses2 = PointPlus.lineGather1(points6);
                for (int z = 0;z < pointPluses2.length;z++) {
                    pointPluses1[z] = pointPluses2[z];
                }

            }else if (i != 0){

                Point[] points5 = utility.longestTall2(points4,pointPluses1);
                Point[] points6 = Point.append2(points3,points5, i + 3);
                Point[] points7 = Point.delete2(points4,points5);

                for (int j = 0;j < points6.length;j++) {
                    points3[j] = points6[j];
                }

                for (int j = 0;j < points7.length;j++) {
                    points4[j] = points7[j];
                }

                PointPlus[] pointPluses2 = PointPlus.lineGather2(points6);

                for (int j = 0;j < pointPluses2.length;j++) {
                    pointPluses1[j] = pointPluses2[j];
                }
            }
        }
        return points3;
    }
}
