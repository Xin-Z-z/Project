package com.fjdz;

import com.fjdz.obj.*;
import com.fjdz.utils.GameUtils;
import sun.font.EAttribute;
import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

//窗口类
//JFrame类是Swing包中最复杂的类，允许程序员将其他组件添加到其中，并将它们组织呈现给用户。
public class GameWin extends JFrame {

    //游戏状态：0（未开始） 1（游戏中） 2（暂停） 3（通关失败） 4（通关成功）
    public static int state = 0;
    //游戏得分
    public static  int score = 0;
    //双缓存的图片
    public Image offScreenImage = null;
    //窗口的宽度
    public int width = 700;
    //窗口的高度
    public int height = 900;
    //游戏的重绘次数
    public int count = 1;
    //敌机出现的数量
    public int enemyCount = 0;

    //背景图对象
    public BgObj bgObj = new BgObj(GameUtils.bgImg,0,-2000,2);
    //我方飞机对象
    public PlaneObj planeObj = new PlaneObj(GameUtils.planeImg,350, 600,44,66,0,this);
    //敌方boss的对象
    public BossObj bossObj = null;

    //启动方法
    public void launch() {

        //设置窗口是否可见
        this.setVisible(true);
        //设置窗口大小
        this.setSize(width,height);
        //设置窗口位置
        this.setLocationRelativeTo(null);
        //设置窗口标题
        this.setTitle("訫之助的飞机大战");

        //游戏物体集合
        GameUtils.gameObjList.add(bgObj);
        GameUtils.gameObjList.add(planeObj);

        //游戏的点击启动事件（鼠标）
        this.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getButton() == 1 && state == 0) {
                    state = 1;
                    repaint();
                }
            }
        });

        //暂停
        this.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == 32) {
                    switch (state) {
                        case 1:
                            state = 2;
                            break;
                        case 2:
                            state = 1;
                            break;
                        default:
                    }
                }
            }
        });

        //重复绘制
        while (true) {

            if (state == 1) {
                createObj();
                repaint();
            }

            try {
                Thread.sleep(25);//每25毫秒生成并绘制一架敌方飞机
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    //重写paint方法，绘制图片
    @Override
    public void paint(Graphics g) {

        if (offScreenImage == null) {
            offScreenImage = createImage(width,height);
        }

        Graphics gImage = offScreenImage.getGraphics();
        gImage.fillRect(0,0,width,height);

        //未开始
        if (state == 0) {

            gImage.drawImage(GameUtils.bgImg,0,0,700,900,null);
            gImage.drawImage(GameUtils.bossImg,250,100,200,200,null);
            gImage.drawImage(GameUtils.explodeImg,250,700,200,200,null);

            GameUtils.drawWord(gImage,"点击开始游戏",Color.yellow,60,160,500);
        }

        //运行中
        if (state == 1) {

            GameUtils.gameObjList.addAll(GameUtils.explodeObjList);

            for (int i = 0; i < GameUtils.gameObjList.size(); i++) {
                GameUtils.gameObjList.get(i).paintSelf(gImage);
            }

            GameUtils.gameObjList.removeAll(GameUtils.removeList);
        }

        //失败
        if (state == 3) {

            gImage.drawImage(GameUtils.explodeImg, planeObj.getX() - 25, planeObj.getY() - 25, 92, 130, null);

            GameUtils.drawWord(gImage,"GAME  OVER",Color.red,60,180,500);

        }

        //通关
        if (state == 4) {

            gImage.drawImage(GameUtils.explodeImg, bossObj.getX() - 10, bossObj.getY() - 60, 184, 260, null);

            GameUtils.drawWord(gImage,"游戏通关",Color.green,80,180,500);
        }

        //计分面板
        if (state == 1 || state == 2 || state ==3 || state ==4) {
            GameUtils.drawWord(gImage,score + "分",Color.CYAN,40,30,100);
        }

        g.drawImage(offScreenImage,0,0,null);
        count++;
        System.out.println(GameUtils.gameObjList.size());
    }


    //生成
    public void createObj() {

        //我方子弹
        if (count % 20 == 0) {
            GameUtils.shellObjList.add(new ShellObj(GameUtils.shellImg,planeObj.getX() + 13,planeObj.getY() - 16,15,15,5,this));
            GameUtils.gameObjList.add(GameUtils.shellObjList.get(GameUtils.shellObjList.size() - 1));
        }

        //敌方子弹
        if (count % 25 == 0 && bossObj != null) {
            GameUtils.bulletObjList.add(new BulletObj(GameUtils.bulletImg,bossObj.getX() + 70,bossObj.getY() + 85,15,15,5,this));
            GameUtils.gameObjList.add(GameUtils.bulletObjList.get(GameUtils.bulletObjList.size() - 1));
        }

        //敌机
        if (count % 35 == 0) {
            GameUtils.enemyObjList.add(new EnemyObj(GameUtils.enemyImg,(int)(Math.random() * 13) * 50,0,73,54,5,this));
            GameUtils.gameObjList.add(GameUtils.enemyObjList.get(GameUtils.enemyObjList.size() - 1));
            enemyCount ++;
        }

        //Boss出现判断
        if(enemyCount > 30 && score > 15 && bossObj == null) {
            bossObj = new BossObj(GameUtils.bossImg,250,35,155,100,5,this);
            GameUtils.gameObjList.add(bossObj);
        }
    }
}
