package com.fjdz.utils;

import com.fjdz.obj.*;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

//工具类
public class GameUtils {

    /*
    Toolkit 的子类被用于将各种组件绑定到特定本机工具包实现。
    以下是采用ToolKit读取硬盘上的图片,
    拿到默认工具包，通过工具包的方法把硬盘上的图片拿到内存中来。
     */

    //背景图片
    public static Image bgImg = Toolkit.getDefaultToolkit().getImage("imgs/bg.jpg");

    //boos图片
    public static Image bossImg = Toolkit.getDefaultToolkit().getImage("imgs/boss.png");

    //爆炸图片
    public static Image explodeImg = Toolkit.getDefaultToolkit().getImage("imgs/explode/e6.gif");

    //我方飞机图片
    public static Image planeImg = Toolkit.getDefaultToolkit().getImage("imgs/plane.png");

    //我方子弹图片
    public static Image shellImg = Toolkit.getDefaultToolkit().getImage("imgs/bulletYellow.png");

    //敌方子弹图片
    public static Image bulletImg = Toolkit.getDefaultToolkit().getImage("imgs/bulletGreen.png");

    //敌机图片
    public static Image enemyImg = Toolkit.getDefaultToolkit().getImage("imgs/enemy.png");

    /*
    Java集合就像一个容器，可以存储任何类型的数据，也可以结合泛型来存储具体的类型对象。
    在程序运行时，Java集合可以动态的进行扩展，随着元素的增加而扩大。
    在Java中，集合类通常存在于java.util包中。
     */

    /*
    ArrayList底层通过数组实现，随着元素的增加而动态扩容。
    ArrayList是Java集合框架中使用最多的一个类，是一个数组队列，线程不安全集合。
     */

    //所有游戏物体集合
    public static List<GameObj> gameObjList = new ArrayList<>();

    //要删除元素的集合
    public static List<GameObj> removeList = new ArrayList<>();

    //我方子弹的集合
    public static List<ShellObj> shellObjList = new ArrayList<>();

    //敌方子弹的集合
    public static List<BulletObj> bulletObjList = new ArrayList<>();

    //敌机的集合
    public static List<EnemyObj> enemyObjList = new ArrayList<>();

    //爆炸的集合
    public static List<ExplodeObj> explodeObjList = new ArrayList<>();


    //绘制字符串工具类
    public static void drawWord(Graphics gImage,String str,Color color,int size,int x,int y) {

        gImage.setColor(color);//设置颜色
        gImage.setFont(new Font("仿宋",Font.BOLD,size));//设置字体
        gImage.drawString(str,x,y);//在(x，y)处绘制str字体
    }
}
